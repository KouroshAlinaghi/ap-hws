#include "app.hpp"

int main() {
    App futball_fantasy;
    futball_fantasy.start();
    return 0;
}
