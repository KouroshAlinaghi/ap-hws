#include "admin.hpp"

using namespace std;

bool Admin::is_admin() {
    return true;
}
